#include "main.h"
int sub_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3)
{

  delete_before_zero(head1,tail1);//1 st digit is zero remove zero 
  delete_before_zero(head2,tail2);

   int count1=div_count(head1,tail1);//call the count funtion coun1
   int count2=div_count(head2,tail2);//call the count funtion coun2

    int flag=0;//take flag variable

    //if it is temp1 is small 
     if(count1<count2)
        {  
             
          Dlist *temp;
     //change the head address
         temp=*head1;
         *head1=*head2;
         *head2=temp;
    //change tail address
        temp=*tail1;
         *tail1=*tail2;
         *tail2=temp;

         flag=1;//negative value

        }
         else if(count1 == count2)
         { 
         Dlist *temp11=*head1;
        Dlist *temp21=*head2;
        //suppose two linked list is same also (2-2) omly one data
        if((*head1==*tail1) && (*head2==*tail2) && (temp11->data==temp21->data))
        {
                  dl_insert_first(head3,tail3,0);
                  return 0;           
        }
         while(1)//infinity loop some time null after include data
         {
          //if condition 1 st is small
            if(temp11->data < temp21->data)
            {
             Dlist *temp;
        //change the head address
         temp=*head1;
         *head1=*head2;
         *head2=temp;
       //change the tail address
        temp=*tail1;
         *tail1=*tail2;
         *tail2=temp;

         flag=1;
           
            break;//after going to subraction
            }
            //1st list is subract 2 nd list   
          if(temp11->data > temp21->data)
          {
            printf("temp11->data=%d\n",temp11->data);
           break;//no need to change the address
          }              
          temp11=temp11->next;//traverse the head1
           temp21=temp21->next;//traverse the head2

           if(temp11==NULL)//loop is take null it is break it
           {
            break;
           }
         }
        }
   Dlist *temp1=*tail1;//the subraction is tail to head
    Dlist *temp2=*tail2;
    while(1)
        {
        if(temp1->data < temp2->data)
        {
          Dlist *borrow=temp1->prev;//the previous value is store the borrow

           while(borrow != NULL && borrow->data==0)//it is previos is zero
           {
            borrow->data=9;//(10-1) so store 
            borrow=borrow->prev;//it iprev is zero continuos check
           }
           if(borrow != NULL)//it is previous is non zero
           {
            borrow->data-=1;//just subract 1
           }
           temp1->data+=10;//data is add 10
        }
        int result=temp1->data-temp2->data;//subract the two data


        dl_insert_first(head3,tail3,result);//insert the first one by one

        temp1=temp1->prev;

        temp2=temp2->prev;

        if(temp2==NULL)//suppose temp2 data rech to null so no data
        {
        while(temp1 != NULL)//temp1 is data is there
        {
            result=temp1->data;

        dl_insert_first(head3, tail3,result);//insert only temp1->data

        temp1=temp1->prev;//traverse only temp1 data
        }
        break;//both are null data
        }
     //it is break the two traverse temp   
     if((temp1==NULL) &&(temp2==NULL))
     {
       break;
     }
    }
delete_before_zero(head3,tail3);//delete the zero for begining in result
     if(flag==1)//it is used to collect negative sign
      {
        return -1;
      }

}

       
