#include "main.h"

//add the two linked list
int add_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3)
{

    int carry=0;//initialise carry
    Dlist *temp1=*tail1;//take linkeded list store the tail to head 
    Dlist *temp2=*tail2;
   while(1)
  {
    //addd the 2 data
    int result=temp1->data+temp2->data+carry;

    //store with carry
   carry=result/10;

    //store with result using reminder
    result=result%10;

    //insert the data in tail to head in result head
    dl_insert_first(head3, tail3,result);


    temp1=temp1->prev;//traverse temp 1

     temp2=temp2->prev;//traverse temp 2

    if(temp2==NULL)//the last is null means loop break
    {
        //temp 1  is not a null data is there temp 2
        while(temp1 != NULL)
        {
          //again operation of sum
          result=temp1->data+carry;//only add temp1 data with carry
         
           carry=result/10;

           result=result%10;

       dl_insert_first(head3,tail3,result);//insert the resut head 3

       temp1=temp1->prev;//traverse only temp 1

        }
        //suppose any carry value is carry is there it was  store it
        if(carry==1)
        {
            dl_insert_first(head3,tail3,1); 
        }
        break;//insert after break
    }

   //suppose 1 list is going to null
   if(temp1==NULL)
    {
        //2 nd list no reach to null
        while(temp2 != NULL)
        {
          
          result=temp2->data+carry;//only addd with temp2 data with carry
         
           carry=result/10;

           result=result%10;

       dl_insert_first(head3,tail3,result);//insert the result in tail 

       temp2=temp2->prev;//traverse the temp2

        }
        //remaining carry there means it is stored it
        if(carry==1)
        {
            dl_insert_first(head3,tail3,1); 
        }
        break;//break the loop
    }

  }
  //if you have come zero is delete it
  delete_before_zero(head3,tail3);
 }