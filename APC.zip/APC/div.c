#include "main.h"

//it is checking which list is big fuction
 int compare_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2)
 {

   int count1=div_count(head1,tail1);//count the node in list1
   int count2=div_count(head2,tail2);//count the node in list2

   //chaeck 1st list is less than second list
   if(count1<count2)
   {
     return -1;
   }
   if(count1>count2)////chaeck 2st list is less than 1st list
   {
    return 1;
   }
   //list is equal
   if(count1==count2)
   {
Dlist *temp11=*head1;//store the head1 in temp1
Dlist *temp21=*head2;//store the head2 in temp2

             while(temp11 != NULL)//anyone is NULL check is enough
         {
            if(temp11->data < temp21->data)//just 1st data is less than 2nd tata stop the subractiion
            {
            return -1;
            }
            if(temp11->data > temp21->data)//it is continue the process this is posible to divide
            {
              return 1;
            }
                 
           temp11=temp11->next;//travrese head to tail list 1
           temp21=temp21->next;//traverse head to tali list2

            }
    }
    return 0;
  }
  
int div_sub__two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3)
{
  
    Dlist *temp1=*tail1;//the subraction is tail to head
    Dlist *temp2=*tail2;
    if((*head1==*tail1) && (*head2==*tail2) && (temp1->data==temp2->data))
        {
            dl_insert_first(head3,tail3,0);
            return 0;              
        }
    while(1)
    {
       
        if(temp1->data < temp2->data)//chck this condtion only need barrow
        {
           Dlist *borrow=temp1->prev;//the previous value is store the borrow

           while(borrow != NULL && borrow->data==0)//it is previos is zero
           {
            borrow->data=9;//(10-1) so store 
            borrow=borrow->prev;//it iprev is zero continuos check
           }
           if(borrow != NULL)//it is previous is non zero
           {
            borrow->data-=1;//just subract 1
           }
           temp1->data+=10;  //data is add 10          
        }
        int result=temp1->data-temp2->data;//subract the two data


        dl_insert_first(head3,tail3,result);//insert the first one by one

        temp1=temp1->prev;

        temp2=temp2->prev;

        if(temp2==NULL)//suppose temp2 data rech to null so no data
        {
        while(temp1 != NULL)//temp1 is data is there
        {
            result=temp1->data;

        dl_insert_first(head3, tail3,result);//insert only temp1->data

        temp1=temp1->prev;//traverse only temp1 data
        }
        break;
        }
     //it is break the two traverse temp  
     if((temp1==NULL) && (temp2==NULL))
     {
       break;
     }
    }
   delete_before_zero(head3,tail3);//delete the zero for begining in result
   return 0;
  }
  //count the result in stored count node
void  count_link(Dlist **head,Dlist **tail)
{
  Dlist *temp=*tail;
  int carry=1;//all  time the carry is one (99+1)
  while(temp!=NULL)
  {
    int sum=temp->data+carry;//find count

    temp->data=sum % 10;//upadte count

    carry = sum /10;//upate the carry

    temp=temp->prev;//traverse the count temp

  }
  if(carry)
  {
    dl_insert_first(head,tail,carry);
    
  }
}
int div_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3)
{ 
    int ret;//just collect fuction return
    
    delete_before_zero(head1,tail1);//delete before zero is an remove 1st node
  delete_before_zero(head2,tail2);//delete before zero is an remove 2 nd node

  //list 1 or 2 begin with zero bot possible to divide 0123
  if(((*head1)->data==0)||((*head2)->data==0))
          {
              return -1;
         }

    if((ret=compare_list(head1,tail1,head2,tail2))==-1)//list-1 is smaller than list-2
    {
      dl_insert_first(head3,tail3,0);//insert only zero
      return 0;
    }
    Dlist *counth=NULL;//count header take anothther list1
    Dlist *countt=NULL;
     dl_insert_first(&counth,&countt,0);//insert the 1st in '0' in intial
    
    
     while(compare_list(head1,tail1,head2,tail2) != -1)//loop checking list1 is greater  
     {
       Dlist *temh=NULL;//the subraction value stored in list
   Dlist *temt=NULL;//address is stored null

      div_sub__two_link(head1,tail1,head2,tail2,&temh,&temt);//the 2 link subract step by step
      *head1=NULL;
     *tail1=NULL;

      *head1=temh;//the subract result is store in update head
      *tail1=temt;//the subract result is store in update tail
      count_link(&counth,&countt);

     }
     //the list2 is great strored result upadete head3
      *head3=counth;
       *tail3=countt;
}