#ifndef DLL_H
#define DLL_L

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define SUCCESS 0
#define FAILURE -1
#define LIST_EMPTY -2
#define DATA_NOT_FOUND -3

typedef struct node
{
	int data;
	char ch;
	struct node *prev;
	struct node *next;
}Dlist;

int dl_insert_last(Dlist **head, Dlist **tail, int data);
int dl_insert_first(Dlist **head, Dlist **tail, int data);
void delete_list(Dlist **head,Dlist **tail);
int add_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3);
int sub_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3);
int mul_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3);
int div_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3);
int div_sub__two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3);
void print_list_neg(Dlist *head);
void remove_simple(Dlist **head);
void delete_before_zero(Dlist **head,Dlist **tail);
int div_count(Dlist **head,Dlist **tail);
void print_list(Dlist *head);
 int compare_list_sign(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,int count1,int count2);
  int compare_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2);
#endif