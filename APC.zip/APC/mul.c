 #include "main.h"


int mul_two_link(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **head3,Dlist **tail3)
 {
  
  delete_before_zero(head1,tail1);//delete before zero is an remove 1st node
  delete_before_zero(head2,tail2);//delete before zero is an remove 2 nd node

     
  //it is using to add value stored temporary
    Dlist *temph_res=NULL;//taking one temp node head
    Dlist *tempt_res=NULL;//taking one temp node tail

     dl_insert_first(&temph_res,&tempt_res,0);//1st initially insert 0 only
    //multiple data1*data2 store it
     Dlist *mulh=NULL;//taking one mul node head
     Dlist *mult=NULL;//taking one mul node tail


    int result;
    int count=0;

     Dlist *temp1=*tail1;//take in traverse tail to head
    Dlist *temp2=*tail2;
      //there are 2 loops are need it traver temp1 and temp2
        while(1)
        {
           Dlist *mulh=NULL;//it is null ater stored value head 
          Dlist *mult=NULL;//it is  null ater storeed value tail

          temp1=*tail1;//temp1 again coming it is taking to tail
            int carry=0;//carrry intialise with zero
            while(1)
            {
                result=(temp1->data)*(temp2->data)+carry;//multiplication 2 data also add carry

                carry= result/10;//store the carry is 

                result=result %10;//store the result using remider

                dl_insert_first(&mulh,&mult,result);//insert at the 1st

                temp1=temp1->prev;//traverse the temp1 data 
            if(temp1 == NULL)//temp1 
            {
                if(carry !=0)//check the carry is there or not
                {
                 dl_insert_first(&mulh,&mult,carry);//insert the carry at 1st
                }
                break;//1st loop outer to loop
            }
        }
        //take 1 by one value temp2 it isert zero in loop
         for(int i=0;i<count;i++)
         {
             dl_insert_last(&mulh,&mult,0);//insert at zero at last
         }
         count++;//increment count

      //call the add function
       add_two_link(&mulh,&mult,&temph_res,&tempt_res,head3,tail3);//store the add value in haed3
     
      delete_list(&temph_res,&tempt_res);// before data is delete

       temph_res=*head3;//stored the add data to update head
        tempt_res=*tail3;//store add the data to update tail

         *head3=NULL;//free to the result after upadte the result head
         *tail3=NULL;//free to the result after upadte the result tail
     temp2=temp2->prev;//traverse the temp2
           if(temp2 == NULL)
            {
                break;
            }    
        }
     *head3=temph_res;//data finished stored the result in head3
     *tail3=tempt_res;//data finished stored the result in head3

 }