
/*DOCUMENTATION:
  NAME: SARAVANAN.K
  REG_NO: 25031_072
  START_DATE:12-04-2026
  END_DATE: 18-04-2026
  DESC: An Arbitrary Precision Calculator (APC) is a program designed to perform mathematical operations
 on very large numbers that exceed standard data type limits.It uses data structures like linked lists or 
 arrays to store and process numbers digit by digit.The calculator supports operations such as addition, 
 subtraction, multiplication, and division with high accuracy.
*/
#include "main.h"
//compare the list 1 and list 
int compare_list_sign(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,int count1,int count2)
 {
   if(count1<count2)
   {
     return -1;
   }
   if(count1>count2)
   {
    return 1;
   }
   if(count1==count2)
   {
Dlist *temp11=*head1;
        Dlist *temp21=*head2;
             while(temp11 != NULL)
         {
            if(temp11->data < temp21->data)
            {
            return -1;
            }
            if(temp11->data > temp21->data)
            {
              return 1;
            }
                 
           temp11=temp11->next;
           temp21=temp21->next;

            }
    }
    return 0;
  }
  
//the function 000123->123
void delete_before_zero(Dlist **head,Dlist **tail)
{
 Dlist *temp3=*head;

    while((*head)->data == 0 && *head != *tail)//only one zero is remaining 000->0
    {

        *head=(*head)->next;

        (*head)->prev=NULL;

        free(temp3);

        temp3=temp3->next;

    }
  }
  //The -123->123 function 
  void remove_simple(Dlist **head)
  {
    if((*head)->data == -3)//check the simple is negative or not
    {
        Dlist *temp=*head;

        *head=(*head)->next;

        (*head)->prev=NULL;

          free(temp);//free the memory 

    }
  }
  //count list 1 and list 2
int div_count(Dlist **head,Dlist **tail)
{
  Dlist *temp=*head;
  int count=0;
   while(1)
   {

    count++;
    temp=temp->next;//traverse the node
    if(temp==NULL)
    {
      break;
    }

   }
   return count;//count is return

}
int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
    
	//Allocating the memory for new node
	Dlist *new = malloc(sizeof (Dlist));

	// If the node is not created the returning failure
	if (!new)
	{
		return FAILURE;
	}
	new -> data = data;
	new -> prev = NULL;
	new -> next = NULL;

	// If the list is empty then inserting the node as first node
	if (!*head && !*tail)
	{	
		*head = *tail = new;
		return SUCCESS;
	}
	new -> prev = *tail;
	(*tail) -> next = new;
	*tail = new;
	return SUCCESS;
}
//insert the data in 1st
int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
   Dlist *new=malloc(sizeof(Dlist)); 
   if(new==NULL)
    {
        return FAILURE;
    }
    
     new->data=data;
     
      new->prev=NULL;
      
       new->next=NULL;
    
    
   
if(*head!=NULL)//list is empty
    {
        new->next=*head;
        
        (*head)->prev=new;
        
         *head=new;
        return SUCCESS;
    }
    //it is stored list non empty
    else
    {
    *head=new;
    
    *tail=new;
    
    return SUCCESS;
       }     
}
//checkin the digit or not 
int is_all_digits(char *string)
{
    int i=0;
    //-123 is an allowe it
    if((string[0]=='-')||(string[0]=='+'))
    {

        i++;//increment in 1
        
        if(string[i] == '\0')//'-' only there fail 
        {
            return FAILURE;
        }
    }
    while(string[i])
    {
     
      if(!isdigit(string[i]))//(a123) check result is fail
      {
        return FAILURE;
      }
        i++;
    }
}
//the list is an free 
void delete_list(Dlist **head,Dlist **tail)
{
    if(*head==NULL)//list is empty don't need to delete
    {
        printf("list is empty");
        return;
    }
    
Dlist *temp=*head;
    while(temp->next != NULL)//it is need deleting one by one
 {
    Dlist *temp1=*head;

    *head=(*head)->next;

    (*head)->prev=NULL;

     free(temp1);

     temp=temp->next;

 }
 if(*head==*tail)//it is only one is there 
    {
        Dlist *temp1=*head;

        *head=NULL;

        *tail=NULL;

        free(temp1);
    }
}
int main(int argc,char *argv[])
{

    int ret;
    Dlist *head1 = NULL; /* initialize the header to NULL */
	Dlist *tail1 = NULL; /* initialize the tail to NULL */

    Dlist *head2 = NULL; /* initialize the header to NULL */
	Dlist *tail2 = NULL; /* initialize the tail to NULL */

    Dlist *head3 = NULL; /* initialize the header to NULL */
	Dlist *tail3 = NULL; /* initialize the tail to NULL */

    if(argc != 4)//check the ./a.out 1234 + 1234 
    {
        printf("INVALID ARGUMENT-1\n");
        return 0;
    }
    if((ret=is_all_digits(argv[1]))==FAILURE)//check list-1 is digit or not
    {
        printf("argv[1] is an invalid argument\n");
        return 0;
    }
     if((ret=is_all_digits(argv[3]))==FAILURE)//check list 2 is digit or not
    {
        printf("argv[3] is an invalid argument\n");
        return 0;
    }

    int i=0;
    char ch1;
//only take char one by one
    while(ch1=argv[1][i])
    {
         dl_insert_last(&head1,&tail1,ch1-'0');//it is insert the number char to num
         i++;
    }
    print_list(head1);
    i=0;
    char ch2;
    //only tale list 2 one by one
    while(ch2=argv[3][i])
    {
         dl_insert_last(&head2,&tail2,ch2-'0');//it is conver to list2 number 
         i++;

    }  
    print_list(head2);

    //In addtion operation 
    if(strcmp(argv[2],"+")==0)
    {
        //check the the both or negative
        if(head1->data==-3 && head2->data==-3)
        {
            remove_simple(&head1);
             remove_simple(&head2);
            add_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);//call the addition function
            print_list_neg(head3);//print the negative
            return 0;
        }
        //check the list 1 is negative
        if(head1->data==-3)
        {
            remove_simple(&head1);
        int count1=div_count(&head1,&tail1);
        int count2=div_count(&head2,&tail2);
        sub_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);//call the subration function
       if((ret=compare_list_sign(&head1,&tail1,&head2,&tail2,count1,count2))==1)//check the which list is greater
       {
        print_list_neg(head3);//print the negative result
        return 0;
       }

        print_list(head3);//print the positive result
        return 0;
        }
        if(head2->data==-3)
        {
            remove_simple(&head2);
        int count1=div_count(&head1,&tail1);
        int count2=div_count(&head2,&tail2);


        sub_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);//call the subraction

       if((ret=compare_list_sign(&head1,&tail1,&head2,&tail2,count1,count2))==-1)//it is list 1 is less list 2 
       {
        print_list_neg(head3);//print the nagative
        return 0;
       }
       print_list(head3);//print the positive
        return 0;
        }

        add_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
        print_list(head3);
        return 0;
    }
    //take the '-'  subraction operation 
    if(strcmp("-",argv[2])==0)
    {
        if(head1->data==-3 && head2->data==-3)
        {
            remove_simple(&head1);
             remove_simple(&head2);
             int count1=div_count(&head1,&tail1);
        int count2=div_count(&head2,&tail2);

            sub_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);//call the subraction function

        if((ret=compare_list_sign(&head1,&tail1,&head2,&tail2,count1,count2))==1)//list 2 is greater
       {
        print_list_neg(head3);//print the negative result
        return 0;
       }
       print_list(head3);//print the positive result
        return 0;
            
        }
        //checck list 1is negative -123 - 123
        if(head1->data==-3)
        {
            remove_simple(&head1);
            int count1=div_count(&head1,&tail1);
          int count2=div_count(&head2,&tail2);

            add_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
    if((ret=compare_list_sign(&head1,&tail1,&head2,&tail2,count1,count2))==1)//call the list compare 
       {
        print_list_neg(head3);
        return 0;
       }

            print_list(head3);
            return 0;
        }
        //check the list 2 is negative
        if(head2->data==-3)
        {
             remove_simple(&head2);
            int count1=div_count(&head1,&tail1);
          int count2=div_count(&head2,&tail2);

            add_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);//call the add function
    if((ret=compare_list_sign(&head1,&tail1,&head2,&tail2,count1,count2))==-1)
       {
        print_list_neg(head3);
        return 0;
       }
            print_list(head3);
            return 0;
        }


       if((ret=sub_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3))==-1)//call the sub function
       {
        print_list_neg(head3);//print negative result
        return 0;
       }

        print_list(head3);//print + ve result
        return 0;
    }
    //"*"multiplication like 1234 "*" 1234
    if(strcmp("*",argv[2])==0)
    {          
        if((head1->data==-3)&&(head2->data==-3))//both list is negative
        {
             remove_simple(&head1);
             remove_simple(&head2);
            mul_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
             print_list(head3);//positive result only
          return 0;
        }
        if(head1->data==-3)//check one list is negative
        {
             remove_simple(&head1);//remove negative
            mul_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
             print_list_neg(head3);//print the negative 
          return 0;
        }
        if(head2->data==-3)//check one list is negative
        {
             remove_simple(&head2);
            mul_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
             print_list_neg(head3);
          return 0;
        }
       mul_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3);
        print_list(head3);
        return 0;

    }
    //the divtion sybol 1234 /123
    if(strcmp("/",argv[2])==0)
    {
       
         //both list negative result 
        if((head1->data==-3)&&(head2->data==-3))
        {
             remove_simple(&head1);
             remove_simple(&head2);
             //list 1 or 2 begin with zero bot possible to divide 0123
            if((ret=div_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3))==-1);
             {
              printf("The bigin zero list is not possible to divide\n");
              return 0;
             }
             print_list(head3);
          return 0;
        }
        //list 1 is negative->-ve
        if(head1->data==-3)
        {
             remove_simple(&head1);
             //list 1 or 2 begin with zero bot possible to divide 0123
            if((ret=div_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3))==-1);
             {
              printf("The bigin zero list is not possible to divide\n");
              return 0;
             }

             print_list_neg(head3);
          return 0;
        }
        ////list 2 is negative->-ve
         if(head2->data==-3)
        {
             remove_simple(&head2);
             //list 1 or 2 begin with zero bot possible to divide 0123
             if((ret=div_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3))==-1);
             {
              printf("The bigin zero list is not possible to divide\n");
              return 0;
             }
             print_list_neg(head3);
          return 0;
        }
    //list 1 or 2 begin with zero bot possible to divide 0123
        if((ret=div_two_link(&head1,&tail1,&head2,&tail2,&head3,&tail3))==-1)
             {
              printf("The bigin zero list is not possible to divide\n");
              return 0;
             }
        print_list(head3);
        return 0;
            }
    //based only 4 operator +,-,/,* only possible
    else
    {
       printf("the oprator is not present in argv[2]\n");
       return 0;
    }
    
}
